//
//  MovieAPIConstant.swift
//  PerfectMovieDate
//
//  Created by Muhammad Rezky on 30/07/24.
//

import Foundation

struct TMDBMovieServiceConstants {
    static let apiKey = "e6dabb36ab9604bb58a5b14d73cb5d34"
    static let baseURL = "https://api.themoviedb.org/3"
}
