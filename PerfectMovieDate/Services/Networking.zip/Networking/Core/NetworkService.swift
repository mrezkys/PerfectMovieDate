//
//  NetworkService.swift
//  PerfectMovieDate
//
//  Created by Muhammad Rezky on 22/06/24.
//

import Foundation


class NetworkService: NetworkServiceProtocol {
    private let logger: NetworkLoggerProtocol

    required init(logger: NetworkLoggerProtocol = NetworkLogger.shared) {
        self.logger = logger
    }

    func fetchData(
        from urlString: String,
        method: NetworkRequestType,
        headers: [String: String]?,
        requestBody: Encodable?,
        completion: @escaping (Result<Data, Error>) -> Void
    ) {
        guard let url = URL(string: urlString) else {
            completion(.failure(URLError(.badURL)))
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.allHTTPHeaderFields = headers

        if let body = requestBody {
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try? JSONEncoder().encode(body)
        }

        logger.log(request: request)

        URLSession.shared.dataTask(with: request) { data, response, error in
            self.logger.log(response: response, data: data)

            if let error = error {
                completion(.failure(error))
                return
            }

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200, let data = data else {
                completion(.failure(URLError(.badServerResponse)))
                return
            }

            completion(.success(data))
        }.resume()
    }
}
